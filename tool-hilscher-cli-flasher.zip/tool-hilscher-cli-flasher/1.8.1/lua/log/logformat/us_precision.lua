local string = require "string"
local Log    = require "log"
local socket = require "socket"
local date   = require "date"

local sformat = string.format
local ticksPerSecond = date(1,1,1,0,0,1,0):spanticks()
local function date_fmt(now)
  local Y, M, D = now:getdate()
  local h,m,s,t = now:gettime()
  return sformat("%.4d-%.2d-%.2d %.2d:%.2d:%09.6f", Y, M, D, h, m, s + t/ticksPerSecond)
end

local M = {}

function M.new()
  return function (msg, lvl, now)
    return date_fmt(now) .. ' [' .. Log.LVL_NAMES[lvl] .. '] ' .. msg
  end
end

return M
