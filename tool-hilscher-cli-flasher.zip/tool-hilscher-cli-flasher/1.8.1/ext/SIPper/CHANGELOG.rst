Changelog
*********

v0.2.3
------

* Changed uart_handler to version 1.2.1
* Added support of new uart_handler receive routine to make the communication more robust
	* Changed hard coded wait_time with a delay_wait_time
	* Set a maximal recieved data size to the read_sip function
* Added details to executable
* Added LICENSE.txt
* Added CHANGELOG.rst
* Added new version of the read_sip binary

v0.2.2
------

* Added support to use a alternative read_sip file to the CLI
* Modified the retry routine to use different wait times after each retry (2*0,3s / 2*0,4s / 2*0,5s)

v0.2.1
------

* Hotfix the offset query to raise an exception if the offset is not is range

v0.2.0
------

* Added support to build the SIPper as a executable in onedir format
* Added support to build the SIPper on Linux
* Added maker.py as build script
* Added versioning
* Added detect_secure_mode CLI call, to detect the secure mode of a connected netX
* Added load_htbl CLI call, to load a htbl
* Added read_sip CLI call, to read out teh sip content
* Added verify_sig CLI call, to verify a signature of hboot image (htbl/usip)
* Added alternative image for the verify_sig and read_sip function, to use signed images in secure mode
* Added get_uid CLI call, to read out the unique ID from a connected netX
* Updated test cases


v0.1.0
------

* Initial SIPper version.