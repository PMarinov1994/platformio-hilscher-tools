local usipPlayerConf =
{
	tempFolderConfPath = ".tmp",
}

return usipPlayerConf